"""Download only missing official model files, recording the resolved revision."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
from huggingface_hub import HfApi, snapshot_download
from huggingface_hub.errors import GatedRepoError

ROOT = Path(__file__).resolve().parents[2]
MODELS = [('Qwen/Qwen3-0.6B', 'qwen3-0.6b'), ('meta-llama/Llama-3.2-3B-Instruct', 'llama-3.2-3b-instruct')]

def fetch(pair):
    repo, name = pair
    directory = ROOT / 'cache/models' / name
    if (directory / 'phase6_revision.json').exists():
        return
    revision = HfApi().model_info(repo).sha
    print(repo, revision, flush=True)
    provenance = dict(repo=repo, revision=revision, provider='huggingface')
    try:
        snapshot_download(repo, revision=revision, local_dir=directory,
                          allow_patterns=['*.json', '*.safetensors', '*.model', 'merges.txt', 'vocab.json', 'LICENSE*', 'README.md'], max_workers=2)
    except GatedRepoError:
        if repo != 'meta-llama/Llama-3.2-3B-Instruct':
            raise
        from modelscope.hub.snapshot_download import snapshot_download as ms_download
        mirror = 'LLM-Research/Llama-3.2-3B-Instruct'
        ms_download(mirror, revision='master', local_dir=str(directory),
                    allow_patterns=['*.json', '*.safetensors', '*.model', 'LICENSE*', 'README.md', 'USE_POLICY.md'],
                    ignore_patterns=['original/*'], max_workers=2)
        provenance = dict(repo=mirror, provider='modelscope', revision=(directory/'.mv').read_text() if (directory/'.mv').exists() else 'master',
                          requested_model=repo, note='Public ModelScope distribution, same provider used by existing Llama1B; not attributed to the inaccessible HF commit')
    (directory / 'phase6_revision.json').write_text(json.dumps(provenance, indent=2)+'\n')
    print('completed', directory, flush=True)

if __name__ == '__main__':
    with ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(fetch, MODELS))
