"""Dependency-aware tmux orchestration for the authorized Phase6 matrix."""
import json
import os
from pathlib import Path
import shlex
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT/'runs/phase6'
PYTHON = ROOT/'runs/phase5/env/bin/python'
PILOT = 'llama1b-joint512-s42-r1'
JOBS = [
    (PILOT, 'llama-3.2-1b-instruct', 0, 'joint'),
    ('llama1b-fixed-down-s42', 'llama-3.2-1b-instruct', 2, 'fixed-down'),
    ('llama1b-r-only-s42', 'llama-3.2-1b-instruct', 6, 'r-only'),
    ('qwen1p7b-joint-s42', 'qwen3-1.7b', 1, 'joint'),
    ('qwen0p6b-joint-s42', 'qwen3-0.6b', 3, 'joint'),
    ('llama3b-joint-s42', 'llama-3.2-3b-instruct', 5, 'joint'),
]
TASKS = ['test','c4','boolq','piqa','social_iqa','hellaswag','winogrande','arc_easy','arc_challenge','openbookqa']


def read(path, default=None):
    return json.loads(path.read_text()) if path.exists() else default


def write(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2)+'\n')
    temporary.replace(path)


def alive(pid):
    try:
        cmd = Path('/proc')/str(pid)/'cmdline'
        return b'phase6/' in cmd.read_bytes()
    except OSError:
        return False


def gpu_status():
    output = subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.total,memory.used,utilization.gpu','--format=csv,noheader,nounits'], text=True)
    return {int(row[0]):dict(total=int(row[1]), used=int(row[2]), utilization=int(row[3]))
            for line in output.splitlines() for row in [line.split(',')]}


def select_budget(rows):
    rows = sorted(rows, key=lambda row: row['step'])
    for i, row in enumerate(rows):
        later = rows[i+1:]
        if row['step'] >= 128 and len(later) >= 2:
            improvement = (row['ppl'] - min(x['ppl'] for x in later)) / row['ppl']
            if improvement <= .002:
                return dict(steps=row['step'], relative_improvement=improvement,
                            threshold=.002, criterion='earliest>=128 with >=2 later checkpoints; all later best PPL within 0.2%', checkpoints=rows)
    return dict(steps=512, threshold=.002, criterion='no earlier qualifying checkpoint', checkpoints=rows)


def start_train(job, steps, resume=False):
    name, model, gpu, arm = job
    command = [str(PYTHON),str(ROOT/'scripts/phase6/launch.py'),'--name',name,'--model',model,
               '--gpu',str(gpu),'--arm',arm,'--steps',str(steps)]
    if resume:
        command += ['--resume']
    subprocess.run(command, check=True)


def eval_done(output):
    return all((output/t/'results.json').exists() or (output/t/'reuse.json').exists() for t in TASKS)


def start_eval(label, model, package, gpu, status):
    output = BASE/'evaluation'/label
    launch = BASE/'evaluation'/(label+'.launch.json')
    env = dict(CUDA_VISIBLE_DEVICES=str(gpu), PHASE5_MODEL_PATH=str(ROOT/'cache/models'/model),
               PHASE5_SEED='42', PYTHONDONTWRITEBYTECODE='1', TOKENIZERS_PARALLELISM='false',
               HF_HOME=str(ROOT/'cache/huggingface'), HF_DATASETS_TRUST_REMOTE_CODE='1',
               NLTK_DATA=str(ROOT/'runs/capability-eval-20260920/nltk_data'),
               HF_HUB_DOWNLOAD_TIMEOUT='120', HF_HUB_ETAG_TIMEOUT='60',
               OMP_NUM_THREADS='4', MKL_NUM_THREADS='4', PYTORCH_CUDA_ALLOC_CONF='expandable_segments:True',
               PHASE6_MEMORY_FRACTION=str(min(.85,.88-status['used']/status['total'])))
    command = [str(PYTHON),'-u',str(ROOT/'scripts/phase6/evaluate.py'),'--output',str(output)]
    if package:
        command += ['--package',str(package)]
    session = 'phase6-eval-'+label
    log = BASE/'evaluation'/(label+'.log')
    shell = 'exec env '+' '.join(shlex.quote(k+'='+v) for k,v in env.items())+' '+shlex.join(command)+' > '+shlex.quote(str(log))+' 2>&1'
    child = subprocess.run(['tmux','-L','rotation-quant-phase6','new-session','-d','-s',session,'-c',str(ROOT),'-P','-F','#{pane_pid}',shell], check=True, capture_output=True, text=True)
    write(launch,dict(pid=int(child.stdout.strip()),gpu=gpu,session=session,command=command,environment=env,output=str(output)))


def main():
    (BASE/'evaluation').mkdir(exist_ok=True)
    while True:
        snapshot = gpu_status()
        active = []
        for path in [*BASE.glob('*.launch.json'), * (BASE/'evaluation').glob('*.launch.json')]:
            launch = read(path)
            pid = launch.get('pid')
            if pid and alive(pid):
                gpu = int(launch.get('gpu', launch.get('environment',{}).get('CUDA_VISIBLE_DEVICES',-1)))
                if gpu in snapshot:
                    active.append((gpu,pid))
                    if snapshot[gpu]['used']/snapshot[gpu]['total'] >= .9:
                        os.kill(pid, signal.SIGTERM)
                        write(BASE/('memory-stop-'+str(pid)+'.json'),dict(pid=pid,gpu=gpu,snapshot=snapshot[gpu],time=time.time()))
        busy = {gpu for gpu,_ in active}
        budget = read(BASE/'budget.json')
        pilot = read(BASE/PILOT/'progress.json', {})
        if budget is None and pilot.get('stage') == 'completed' and pilot.get('steps') == 512:
            rows = read(BASE/PILOT/'results.json')
            if {row['step'] for row in rows} == set(range(0,513,64)):
                budget = select_budget(rows)
                write(BASE/'budget.json',budget)
        training = {}
        stopped = []
        for job in JOBS:
            name, model, gpu, arm = job
            output = BASE/name
            state = read(output/'progress.json', {})
            training[name] = state
            if output.exists() and state and state.get('stage') != 'completed' and not alive(state.get('pid',0)):
                stopped.append(dict(kind='training',job=name,progress=state,failure=read(output/'failure.json'),
                                    action='inspect failure and resume last coherent checkpoint; do not restart blindly'))
            if name == PILOT:
                continue
            ready = (ROOT/'cache/models'/model/'config.json').exists() and (
                model in ('llama-3.2-1b-instruct','qwen3-1.7b') or (ROOT/'cache/models'/model/'phase6_revision.json').exists())
            if ready and not output.exists() and gpu not in busy:
                start_train(job,128)
                busy.add(gpu)
            elif budget and state.get('stage') == 'completed' and 0 < state.get('steps', 0) < budget['steps'] and gpu not in busy:
                marker = BASE/(name+'-resume-'+str(budget['steps'])+'.launch.json')
                if not marker.exists():
                    start_train(job,budget['steps'],True)
                    busy.add(gpu)
                elif not alive(read(marker).get('pid',0)):
                    stopped.append(dict(kind='training-extension',job=name,required_steps=budget['steps'],launch=str(marker)))
        evaluations = []
        for model in sorted({job[1] for job in JOBS}):
            if model in ('llama-3.2-1b-instruct','qwen3-1.7b') or (ROOT/'cache/models'/model/'phase6_revision.json').exists():
                evaluations.append((model+'-bf16',model,None))
        noopt = BASE/PILOT/'checkpoint-0000/model.pt'
        if (noopt.parent/'cold_reload.json').exists():
            evaluations.append(('llama1b-no-opt','llama-3.2-1b-instruct',noopt))
        if budget:
            for name, model, _, _ in JOBS:
                package = BASE/name/f"checkpoint-{budget['steps']:04d}/model.pt"
                if (package.parent/'validation.json').exists():
                    evaluations.append((name,model,package))
        complete = {}
        for label, model, package in evaluations:
            output = BASE/'evaluation'/label
            complete[label] = eval_done(output)
            marker = BASE/'evaluation'/(label+'.launch.json')
            if not complete[label] and marker.exists() and not alive(read(marker).get('pid',0)):
                stopped.append(dict(kind='evaluation',job=label,launch=str(marker),
                                    failures=[dict(path=str(path),error=read(path)) for path in output.glob('*/failure.json')]))
            if complete[label] or marker.exists():
                continue
            candidates = [g for g in (7,3,5,2,6,1,0) if g not in busy and snapshot[g]['used']/snapshot[g]['total'] < .3]
            if candidates:
                gpu = candidates[0]
                start_eval(label,model,package,gpu,snapshot[gpu])
                busy.add(gpu)
        # Six trained packages, the no-opt package, and four BF16 references.
        done = budget is not None and len(complete) == 11 and all(complete.values())
        write(BASE/'orchestration.json',dict(time=time.time(),pid=os.getpid(),budget=budget,training=training,evaluation=complete,gpus=snapshot,active=active,stopped_incomplete=stopped,completed=done))
        if done:
            subprocess.run([str(PYTHON),str(ROOT/'scripts/phase6/summarize.py')],check=True)
            break
        time.sleep(30)


if __name__ == '__main__':
    main()
