"""Build the requested table from raw results; missing values remain empty."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT/'runs/phase6'
TASK_METRICS = dict(boolq='acc', piqa='acc_norm', social_iqa='acc', hellaswag='acc_norm',
                    winogrande='acc', arc_easy='acc_norm', arc_challenge='acc_norm', openbookqa='acc_norm')
MODELS = [('llama-3.2-1b-instruct','llama1b-joint512-s42-r1'), ('llama-3.2-3b-instruct','llama3b-joint-s42'),
          ('qwen3-0.6b','qwen0p6b-joint-s42'), ('qwen3-1.7b','qwen1p7b-joint-s42')]


def curves():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(2, 2, figsize=(9, 6), constrained_layout=True)
    records = {}
    budget = json.loads((BASE/'budget.json').read_text()) if (BASE/'budget.json').exists() else None
    for ax, (model, name) in zip(axes.flat, MODELS):
        path = BASE/name/'results.json'
        points = json.loads(path.read_text()) if path.exists() else []
        records[model] = points
        if points:
            ax.plot([r['step'] for r in points], [r['ppl'] for r in points], marker='o', color='#2374AB')
        if budget:
            ax.axvline(budget['steps'], color='#BA5C12', linestyle='--', label='Selected T')
            ax.legend(frameon=False)
        ax.set(title=model, xlabel='Optimizer updates (cosine horizon = 512)', ylabel='WikiText-2 validation PPL')
        ax.grid(alpha=.2)
    for extension in ('png', 'pdf'):
        fig.savefig(BASE/('validation_curves.'+extension), dpi=180)
    plt.close(fig)
    (BASE/'validation_curves.json').write_text(json.dumps(records,indent=2)+'\n')


def row(model, method, label):
    values = dict(model=model, method=method)
    sources = {}
    for task in ['test','c4',*TASK_METRICS]:
        directory = BASE/'evaluation'/label/task
        path = directory/'results.json'
        if (directory/'reuse.json').exists():
            path = Path(json.loads((directory/'reuse.json').read_text())['source'])
        if not path.exists():
            values[task] = None
            continue
        data = json.loads(path.read_text())
        sources[task] = str(path)
        if task in ('test','c4'):
            values[task] = data['ppl']
        else:
            values[task] = data['results'][task][TASK_METRICS[task]+',none']*100
    values['avg'] = sum(values[t] for t in TASK_METRICS)/8 if all(values[t] is not None for t in TASK_METRICS) else None
    return values,sources


def sp2_comparison():
    legacy = ROOT/'runs/capability-eval-20260920'
    registry = json.loads((legacy/'models.json').read_text())
    ppl_rows = json.loads((legacy/'ppl_reuse.json').read_text())
    comparisons, evidence = [], {}
    for family, model, current in [('llama','llama-3.2-1b-instruct','llama1b-joint512-s42-r1'),
                                   ('qwen','qwen3-1.7b','qwen1p7b-joint-s42')]:
        new, new_sources = row(model,'Phase6 joint INT16',current)
        comparisons.append(new)
        evidence[current] = new_sources
        for method, label in [('parent','SP2 postprocessed, before distillation'),('firon','SP2 final, after 400-step distillation')]:
            values = dict(model=model, method=label)
            paths = {}
            expected = registry[family][method]
            for task in ['test','c4',*TASK_METRICS]:
                if task in ('test','c4'):
                    match = [r for r in ppl_rows if r['model_key']==family and r['method']==method
                             and r['dataset']==('allenai/c4' if task=='c4' else 'Salesforce/wikitext')]
                    if len(match)!=1 or match[0]['evaluation_package'] != expected['package']:
                        raise ValueError('SP2 package/PPL source mismatch')
                    path = Path(match[0]['evidence_path'])
                    raw = json.loads(path.read_text())
                    values[task] = raw['ppl']
                else:
                    path = legacy/family/method/task/'results.json'
                    if not path.exists():
                        values[task] = None
                        continue
                    settings = json.loads((path.parent/'settings.json').read_text())
                    if settings['selected']['package'] != expected['package'] or settings['num_fewshot'] != 0:
                        raise ValueError('SP2 task artifact/protocol mismatch')
                    raw = json.loads(path.read_text())
                    values[task] = raw['results'][task][TASK_METRICS[task]+',none']*100
                paths[task] = str(path)
            values['avg'] = sum(values[t] for t in TASK_METRICS)/8 if all(values[t] is not None for t in TASK_METRICS) else None
            comparisons.append(values)
            evidence[family+'-'+method] = dict(package=expected['package'],sources=paths)
    with (BASE/'sp2_comparison.csv').open('w') as stream:
        writer = csv.DictWriter(stream,fieldnames=list(comparisons[0])); writer.writeheader(); writer.writerows(comparisons)
    (BASE/'sp2_comparison_sources.json').write_text(json.dumps(evidence,indent=2)+'\n')
    text = ['# 与既有SP2路线对照','', '复用相同模型与评测口径的既有原始结果。SP2蒸馏前包包含后处理，最终包还包含400步蒸馏；两者是路线效果参照，不是与Phase6等预算的单变量消融。明显差距触发实现/导出/评测排查，但不单凭分数判定bug。', '',
            '| Model | Route | WT2 test PPL | C4 subset PPL | 8-task Avg (%) |',
            '| --- | --- | ---: | ---: | ---: |']
    for r in comparisons:
        cells = [r['model'],r['method'],*[('--' if r[k] is None else f'{r[k]:.4f}') for k in ('test','c4','avg')]]
        text.append('| '+' | '.join(cells)+' |')
    (BASE/'SP2_COMPARISON.md').write_text('\n'.join(text)+'\n')


def main():
    rows, sources = [], {}
    for model, label in MODELS:
        for method, key in [('BF16',model+'-bf16'),('joint',label)]:
            values, evidence = row(model,method,key)
            rows.append(values)
            sources[key] = evidence
    for method, label in [('no-opt','llama1b-no-opt'),('R-only','llama1b-r-only-s42'),('fixed-down-SA','llama1b-fixed-down-s42')]:
        values,evidence = row('llama-3.2-1b-instruct',method,label)
        rows.append(values)
        sources[label] = evidence
    with (BASE/'joint_results.csv').open('w') as stream:
        writer = csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (BASE/'joint_result_sources.json').write_text(json.dumps(sources,indent=2)+'\n')
    headers = list(rows[0])
    table = ['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']
    for values in rows:
        table.append('| '+' | '.join('--' if values[h] is None else f'{values[h]:.4f}' if isinstance(values[h],float) else str(values[h]) for h in headers)+' |')
    budget = json.loads((BASE/'budget.json').read_text()) if (BASE/'budget.json').exists() else None
    budget_text = ('统一训练步数尚待Llama1B完成512步validation曲线后确定。' if budget is None else
                   f"统一训练步数T={budget['steps']}，cosine终点始终为512；这是共同训练轨迹的截断点，不是重新压缩到T的完整余弦日程。")
    joint = next(r for r in rows if r['model']=='llama-3.2-1b-instruct' and r['method']=='joint')
    differences = []
    for r in rows:
        if r['model']=='llama-3.2-1b-instruct' and r['method'] in ('no-opt','R-only','fixed-down-SA'):
            diff = dict(comparison='joint minus '+r['method'])
            for metric in ['test','c4',*TASK_METRICS,'avg']:
                diff[metric] = joint[metric]-r[metric] if joint[metric] is not None and r[metric] is not None else None
            differences.append(diff)
    (BASE/'ablation_deltas.json').write_text(json.dumps(differences,indent=2)+'\n')
    (BASE/'JOINT_RESULTS.md').write_text('# Phase6 联合训练结果（自动汇总）\n\n空白表示尚未完成；八项齐全才计算Avg。模型和训练分支不因最终任务分数更换。PPL协议：完整WikiText2 test和固定C4 validation子集；BF16 fakequant，非NPU性能。\n\n'+budget_text+'\n\n'+'\n'.join(table)+'\n\n差值见ablation_deltas.json：joint减对照，PPL负值和accuracy正值有利于joint。单seed结果描述这次配对实验，不解释为统计显著。不同tokenizer的绝对PPL不用于跨模型排名。\n')
    curves()
    sp2_comparison()


if __name__ == '__main__':
    main()
