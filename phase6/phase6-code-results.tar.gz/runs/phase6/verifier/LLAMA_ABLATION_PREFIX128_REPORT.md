# Llama1B ablation 128-update prefix audit

2026-09-21. **PASS for both completed prefixes**. CPU read-only audit; no GPU work, no repeated model evaluation, and no access to the ongoing main experiment's resume file.

Runs: `llama1b-fixed-down-s42` and `llama1b-r-only-s42` under runs/phase6.

Both have exactly128 consecutive training records, eight finite microbatch losses per update, matching recorded means, expected modulo800 window order, and cumulative2097152 input tokens. Every learning-rate factor exactly matches a512-update cosine horizon with10 warmup updates. Both report completed/steps128 with no failure.json.

## Frozen groups and continuation

- fixed-down: on all128 updates, DOWN_SA has zero gradient tensors, zero gradient norm and zero changed elements; R/SA/SW each have gradients and changes. All16 down-SA tensors in resume exactly equal initialization.
- r-only: on all128 updates, SA/SW/DOWN_SA have zero gradients and changes; R has gradients and changes. All224 scale tensors in resume exactly equal initialization. Its evaluation export separately refreshes SW and recalibrates activation scales as specified; the frozen training parameters are not evidence that those exported calibration values remain at initialization.
- Each resume's241 parameter tensors and key coverage exactly match checkpoint-0128/parameters.pt, and both step fields equal128.
- fixed-down has17 SGDG state entries plus208 Adam states; all Adam counters equal128, and first/second moments are finite. r-only has17 SGDG state entries and no Adam optimizer, as intended.
- Saved group learning rates agree with initial_lr multiplied by the last applied factor; Python, Torch CPU and CUDA RNG states are present.
- Next update is129 (index128), using factor0.8697523637458997 and windows224–231. Both saved states are consistent for continuation on the same512-horizon trajectory.

## Validation aggregation

All six checkpoints use252852 input tokens and252728 targets. Original segment counts sum correctly; target-weighted segment NLL and exp(NLL) exactly reproduce each result.

| Arm | Step | Validation NLL | Validation PPL |
|---|---:|---:|---:|
| fixed-down | 0 | 3.402153813549962 | 30.02870668243912 |
| fixed-down | 64 | 2.81257361366409 | 16.65272078628509 |
| fixed-down | 128 | 2.7711230010744545 | 15.97656563966915 |
| r-only | 0 | 3.402153813549962 | 30.02870668243912 |
| r-only | 64 | 2.8443618600729534 | 17.190585169217904 |
| r-only | 128 | 2.8109680783129924 | 16.62600570611228 |

This PASS covers the128-update prefixes and their saved continuation state. It does not declare final selected-budget training or external evaluation complete.
