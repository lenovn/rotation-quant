# Phase6 128-step pause and scheduling review

Date: 2026-09-21. Independent CPU narrow tests: **3 passed in 6.55s**.

Command: `PYTHONDONTWRITEBYTECODE=1 runs/phase5/env/bin/python -m pytest -p no:cacheprovider -q runs/phase6/verifier/test_schedule_resume.py`.

## Resume trajectory

A four-dimensional synthetic parameter problem uses the actual SGDG Stiefel optimizer and Adam. Updates labelled 125,126,127 are followed by atomic saving at completed step128. The saved record includes both parameters, both optimizer states, Python RNG and Torch CPU RNG. Resumed updates 128 and129 are compared with uninterrupted execution. Losses, step factors, window indices, R and scale are bitwise identical. Adam update count is preserved and SGDG optimizer state restored.

The first resumed update calls schedule(128,512,10), uses training windows224–231, and does not restart warmup. Thus pausing at128 does not change the intended 512-horizon cosine trajectory. This CPU test does not establish bitwise CUDA determinism; application source additionally saves/restores CUDA RNG. Legacy live two-file resume accepts only matching saved step values, as reviewed earlier.

## Budget selection

Reviewed `scripts/phase6/schedule.py`. It waits for the pilot to complete512 and provide all steps0,64,...512. It selects the earliest checkpoint at least128 with at least two later checkpoints for which the best PPL across all later checkpoints improves no more than0.2%; otherwise512. Tests verify the two-later requirement, earliest qualifying point, and a late improvement invalidating an apparent early plateau. Training uses validation for this choice; final test/C4/capability evaluation follows selected packages.

Dependency review: new-model training waits for config and phase6_revision; other runs initially target128, then resume to selected T if T>128; evaluation waits for selected checkpoint validation. The scheduler aims for six trained packages, one no-opt package and four BF16 references.

## Remaining operational limitation

Reported to coordinator: a dead/incomplete training run is not restarted because its output directory exists but its stage is not completed; an evaluation failure leaves a launch marker that permanently prevents retry. The same occurs after the scheduler's own memory-triggered SIGTERM. Without explicit failed-job reporting/handling, orchestration can loop forever with completed=false. This does not invalidate cosine continuation or the tested budget function, but unattended eventual completion is not established.
