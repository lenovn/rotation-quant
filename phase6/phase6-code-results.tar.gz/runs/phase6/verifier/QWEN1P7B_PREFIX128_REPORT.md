# Qwen3-1.7B 128-update prefix audit

2026-09-21. **PASS**. CPU read-only verification of `runs/phase6/qwen1p7b-joint-s42`; no GPU execution, training or PPL rerun.

- Exactly128 consecutive training records, each with eight finite microbatch losses. Their means, cumulative token counts and ordered modulo800 window indices recompute exactly; total training input tokens2097152.
- Every schedule factor matches schedule(index,512,10). All four parameter groups have nonzero gradients and changes in every update.
- Resume and checkpoint-0128/parameters.pt both identify step128; all421 parameter tensors and their key coverage match exactly.
- Saved optimizer states contain29 SGDG entries and392 Adam entries. All Adam counters equal128 and both moment tensors are finite. Each stored learning rate matches its initial learning rate times the last applied schedule factor. Python, Torch CPU and CUDA RNG states are present.
- Progress reports completed/steps128, PID852493, with no failure.json.
- Step0/64/128 validation uses262337 input tokens/262208 targets. Segment target totals and token-weighted NLL/PPL independently recompute exactly.

| Step | Validation NLL | Validation PPL |
|---|---:|---:|
| 0 | 4.569522278474163 | 96.4979995882042 |
| 64 | 2.760952733019326 | 15.814903153375539 |
| 128 | 2.702717438942142 | 14.9202214766084 |

Continuation starts update129 at index128, factor0.8697523637458997, windows224–231. Saved state is consistent for continuation of the existing512-horizon trajectory. This audit covers the128-update prefix, not final selected-budget training or external evaluation completion.
