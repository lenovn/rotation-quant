"""Exercise the actual scheduler extension branch without starting processes."""
import ast
from pathlib import Path
import pytest
ROOT=Path('/home/dongpeiyan/projects/rotation-quant')
tree=ast.parse((ROOT/'scripts/phase6/schedule.py').read_text())
branch=next(n for n in ast.walk(tree) if isinstance(n,ast.If) and "state.get('stage') == 'completed'" in ast.unparse(n.test) and "budget['steps']" in ast.unparse(n.test))
code=compile(ast.fix_missing_locations(ast.Module(body=[ast.If(test=branch.test,body=branch.body,orelse=[])],type_ignores=[])),'actual_scheduler_extension_branch','exec')

@pytest.mark.parametrize('steps',[128,256,512])
@pytest.mark.parametrize('budget_steps',[128,256,512])
@pytest.mark.parametrize('stage',['completed','training'])
def test_intermediate_extension_matrix(tmp_path,steps,budget_steps,stage):
 calls=[];job=('qwen1p7b-joint-s42','qwen3-1.7b',1,'joint')
 env=dict(budget={'steps':budget_steps},state={'stage':stage,'steps':steps},gpu=1,busy=set(),BASE=tmp_path,name=job[0],job=job,start_train=lambda *args:calls.append(args))
 exec(code,env)
 expected=stage=='completed' and steps<budget_steps
 assert calls==([(job,budget_steps,True)] if expected else [])
 assert env['busy']==({1} if expected else set())

@pytest.mark.parametrize('state,budget,busy',[({'stage':'completed','steps':0},{'steps':512},set()),({'stage':'completed','steps':128},None,set()),({'stage':'completed','steps':256},{'steps':512},{1})])
def test_extension_requires_positive_progress_budget_and_idle_gpu(tmp_path,state,budget,busy):
 env=dict(budget=budget,state=state,gpu=1,busy=busy,BASE=tmp_path,name='x',job=(),start_train=lambda *args:pytest.fail('unexpected launch'))
 exec(code,env)
