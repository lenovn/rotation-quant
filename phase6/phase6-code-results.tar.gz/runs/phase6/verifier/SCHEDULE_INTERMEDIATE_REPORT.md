# Intermediate-prefix scheduler verification

2026-09-21. **PASS**. Application code unchanged by verifier; no GPU or subprocess launches.

Reviewed the new extension condition in scripts/phase6/schedule.py: stage completed, positive completed steps less than selected budget, and idle GPU. Executed the actual parsed application branch using a mocked start_train, covering all18 combinations of completed/training status, completed steps128/256/512, and budget128/256/512. Extra cases cover missing budget, zero steps and busy GPU.

| Completed steps | T128 | T256 | T512 |
|---|---|---|---|
| 128 | no resume | resume to256 | resume to512 |
| 256 | no resume | no resume | resume to512 |
| 512 | no resume | no resume | no resume |

All training-status combinations produce no new launch. A qualifying extension calls start_train(job, target, True), retaining resume semantics. Thus a manually authorized128→256 prefix can later continue256→512 when the selected T requires it. The change does not reset the cosine horizon or reinitialize learned parameters.

Command: `PYTHONDONTWRITEBYTECODE=1 runs/phase5/env/bin/python -m pytest -p no:cacheprovider -q runs/phase6/verifier/test_schedule_intermediate.py runs/phase6/verifier/test_schedule_resume.py`.

Result: **24 passed in7.27s**. Includes existing real SGDG/Adam synthetic save/restore and budget-function tests. Existing launch-marker handling remains unchanged: an already-issued target launch is not duplicated and a dead extension is reported for handling rather than retried blindly.
