# Qwen3-0.6B 128-update prefix audit

**PASS**. CPU read-only audit, 2026-09-21; no training or PPL evaluation rerun.

Run: `runs/phase6/qwen0p6b-joint-s42`. Progress reports completed, steps128; no failure.json.

- training.jsonl contains exactly128 records, consecutive steps1–128, each with eight finite microbatch losses. Their means, cumulative input tokens and modulo800 ordered window indices all recompute exactly. Total input tokens:2097152.
- Every learning-rate factor exactly follows schedule(index,512,10), not a128-step schedule. Last applied factor(index127)=0.8718514514518616. Continuation's next index128 factor=0.8697523637458997, with windows224–231.
- Atomic resume.pt reports step128. All421 saved parameter tensors exactly match checkpoint-0128/parameters.pt, including matching key coverage and checkpoint step.
- Optimizer records contain29 SGDG states and392 Adam states. All392 Adam counters equal128; first/second moments are present and finite. All saved parameter-group learning rates agree with their initial learning rate times the last recorded factor. Python, Torch CPU and CUDA RNG states are present.
- Full validation uses262337 input tokens/262208 targets. Segment target totals, target-weighted NLL and exp(NLL) reproduce step0/64/128 results exactly.

| Step | Validation NLL | Validation PPL |
|---|---:|---:|
| 0 | 5.042929964334495 | 154.92327034737409 |
| 64 | 3.4144251016945195 | 30.39946780044179 |
| 128 | 3.3076708644894337 | 27.32141602647245 |

The saved state is consistent for continuation from update129 on the same512-horizon trajectory. This audit establishes the completed128-update prefix; it does not claim completion of the later selected budget or external evaluations.
