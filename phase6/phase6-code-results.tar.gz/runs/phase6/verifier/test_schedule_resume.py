import importlib.util
import math
import random
from pathlib import Path
import sys
import torch
import pytest
ROOT=Path('/home/dongpeiyan/projects/rotation-quant')
sys.path.insert(0,str(ROOT/'scripts/phase6'))
import joint
spec=importlib.util.spec_from_file_location('phase6_scheduler',ROOT/'scripts/phase6/schedule.py')
scheduler=importlib.util.module_from_spec(spec);spec.loader.exec_module(scheduler)

def create():
 r=torch.nn.Parameter(torch.eye(4));scale=torch.nn.Parameter(torch.tensor([.07]))
 sgd=joint.SGDG([dict(params=[r],lr=1.5,initial_lr=1.5,stiefel=True)],lr=1.5)
 adam=torch.optim.Adam([dict(params=[scale],lr=.00007,initial_lr=.00007)],eps=1e-12,weight_decay=0)
 return r,scale,[sgd,adam]

def advance(state,index):
 r,scale,opts=state
 factor=joint.schedule(index,512,10)
 for o in opts:
  o.zero_grad(set_to_none=True)
  for g in o.param_groups:g['lr']=g['initial_lr']*factor
 noise=torch.randn(4,4)
 loss=(r*noise).sum()*scale+(scale-.05).square()
 loss.backward()
 for o in opts:o.step()
 return factor,[(index*8+i)%800 for i in range(8)],float(loss.detach())

def test_resume128_preserves_schedule_rng_and_optimizer_state(tmp_path):
 random.seed(42);torch.manual_seed(42)
 original=create()
 # Short synthetic updates labelled with the real indices bracketing stop128.
 for i in [125,126,127]:advance(original,i)
 r,s,opts=original
 path=tmp_path/'resume.pt';temp=path.with_suffix('.tmp')
 torch.save(dict(step=128,parameters=[r.detach().clone(),s.detach().clone()],optimizers=[o.state_dict() for o in opts],python_rng=random.getstate(),torch_rng=torch.get_rng_state()),temp);temp.replace(path)
 expected=[advance(original,i) for i in [128,129]]
 saved=torch.load(path,weights_only=False)
 restored=create()
 with torch.no_grad():
  restored[0].copy_(saved['parameters'][0]);restored[1].copy_(saved['parameters'][1])
 for o,v in zip(restored[2],saved['optimizers']):o.load_state_dict(v)
 random.setstate(saved['python_rng']);torch.set_rng_state(saved['torch_rng'])
 actual=[advance(restored,i) for i in range(saved['step'],130)]
 assert actual==expected
 assert torch.equal(original[0],restored[0]) and torch.equal(original[1],restored[1])
 assert actual[0][1]==list(range(224,232))
 assert actual[0][0]==joint.schedule(128,512,10)>0.8
 assert actual[0][0]!=joint.schedule(0,512,10)
 assert original[2][1].state[original[1]]['step']==5
 assert restored[2][1].state[restored[1]]['step']==5
 assert 'momentum_buffer' in restored[2][0].state[restored[0]]


def rows(values):return [dict(step=s,ppl=p) for s,p in values]

def test_budget_earliest128_and_two_later_required():
 assert scheduler.select_budget(rows([(0,30),(64,21),(128,20),(192,19.99)]))['steps']==512
 assert scheduler.select_budget(rows([(0,30),(64,21),(128,20),(192,19.99),(256,19.98)]))['steps']==128

def test_budget_all_later_not_just_next_two():
 assert scheduler.select_budget(rows([(0,30),(64,21),(128,20),(192,19.99),(256,19.98),(320,18),(384,17),(448,16),(512,15)]))['steps']==512
 assert scheduler.select_budget(rows([(0,30),(64,21),(128,20),(192,18),(256,17),(320,16),(384,15),(448,15),(512,15)]))['steps']==384
