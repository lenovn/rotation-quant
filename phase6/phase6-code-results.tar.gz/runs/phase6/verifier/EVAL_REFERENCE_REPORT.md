# Phase6 evaluation reference audit

2026-09-21. **PASS**. Read-only audit; no GPU or evaluation rerun.

Qwen3-0.6B BF16 has all ten raw results. Eight tasks have complete, unique sample IDs and sample counts matching both original/effective counts; recomputing the selected metric from sample JSONL exactly reproduces results. All task configurations are zero-shot; quantization records have no quantizer calls, as expected for BF16.

| Task | Metric | Samples | Score (%) |
|---|---|---:|---:|
| BoolQ | acc | 3270 | 63.700306 |
| PIQA | acc_norm | 1838 | 67.791077 |
| SIQA | acc | 1954 | 39.150461 |
| HellaSwag | acc_norm | 10042 | 47.251544 |
| WinoGrande | acc | 1267 | 56.195738 |
| ARC Easy | acc_norm | 2376 | 55.976431 |
| ARC Challenge | acc_norm | 1172 | 34.215017 |
| OpenBookQA | acc_norm | 500 | 31.600000 |

Unweighted eight-task mean: **49.485071648017424%**, matching joint_results.csv. WikiText-2 test PPL **20.9678441151121** uses 299078 input tokens / 298931 targets. Fixed C4 validation PPL **30.628664122123187** uses 2097152 inputs / 2096128 targets. Segment target counts, weighted NLL and exp(NLL) independently recompute exactly.

SP2 comparison audit: all four historical rows reproduce their linked raw PPL/task results and use the registry's matching package. Eight-task averages are Llama postprocessed **50.990144858630124%**, Llama distilled **52.19608151254703%**, Qwen postprocessed **54.16533562024014%**, Qwen distilled **56.36920144163138%**. Source paths are recorded in sp2_comparison_sources.json; task settings identify those packages. SP2_COMPARISON.md explicitly distinguishes postprocessing and additional 400-step distillation and states these are route references, not equal-budget single-variable ablations. Missing Phase6 final values remain blank.

Current orchestration.json reports stopped_incomplete=[]; this is a point-in-time status, not evidence that ongoing training has completed.

## Additional completed references

**PASS**, read-only audit of Llama-3.2-3B BF16 and Llama1B no-opt; Qwen0.6B audit was not repeated.

Both new rows have complete eight-task sample logs: BoolQ3270, PIQA1838, SIQA1954, HellaSwag10042, WinoGrande1267, ARC Easy2376, ARC Challenge1172, OpenBookQA500. Unique sample IDs and original/effective counts agree. Sample-level sums reproduce each chosen metric (same acc/acc_norm mapping above), and unweighted means agree exactly with joint_results.csv.

| Reference | Eight-task mean (%) | WT2 test PPL | C4 validation PPL |
|---|---:|---:|---:|
| Llama-3.2-3B BF16 | 60.99522608621606 | 11.049524232637005 | 16.894590412754148 |
| Llama1B no-opt | 46.434712828718375 | 28.423738931192467 | 45.48045487808398 |

Both use WT2 test289076 inputs/288934 targets and C4 validation2097152 inputs/2096128 targets. Segment weighting and exp(NLL) exactly reproduce the reported PPLs.

No-opt evaluation settings all point to `llama1b-joint512-s42-r1/checkpoint-0000/model.pt`, with no training/calibration/selection. Inspected the package on CPU:112 packed W4 records and112 activation records, including96 INT8 and16 INT16, all activation scales finite and positive. Every one of the ten no-opt tasks reports positive execution counts for all112 quantizers and scales_unchanged=true. BF16 records contain zero quantizers as expected.

Read-only first-update evidence for all four model mainlines confirms nonzero down-SA gradients and changes: Llama1B16/16, Llama3B28/28, Qwen0.6B28/28, Qwen1.7B28/28. Llama3B checkpoint0 cold_reload.json reports exact=true. These are startup/update observations, not completed training outcomes.
