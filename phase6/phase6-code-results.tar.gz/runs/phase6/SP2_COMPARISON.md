# 与既有SP2路线对照

复用相同模型与评测口径的既有原始结果。SP2蒸馏前包包含后处理，最终包还包含400步蒸馏；两者是路线效果参照，不是与Phase6等预算的单变量消融。明显差距触发实现/导出/评测排查，但不单凭分数判定bug。

| Model | Route | WT2 test PPL | C4 subset PPL | 8-task Avg (%) |
| --- | --- | ---: | ---: | ---: |
| llama-3.2-1b-instruct | Phase6 joint INT16 | -- | -- | -- |
| llama-3.2-1b-instruct | SP2 postprocessed, before distillation | 15.5602 | 27.4396 | 50.9901 |
| llama-3.2-1b-instruct | SP2 final, after 400-step distillation | 14.1544 | 26.9848 | 52.1961 |
| qwen3-1.7b | Phase6 joint INT16 | -- | -- | -- |
| qwen3-1.7b | SP2 postprocessed, before distillation | 14.3022 | 24.9033 | 54.1653 |
| qwen3-1.7b | SP2 final, after 400-step distillation | 14.1512 | 24.2470 | 56.3692 |
